# Flutterwave Live Webhook Server

This is a small HTTPS-ready Node.js endpoint for receiving Flutterwave webhooks.

## Endpoint

POST `/webhooks/flutterwave`

Once deployed, your Flutterwave URL will be:

`https://YOUR-DOMAIN/webhooks/flutterwave`

## Local setup

1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `FLW_SECRET_HASH` to the exact secret hash configured in Flutterwave.
5. Run `npm start`.

## Important

The deployed URL must be HTTPS and publicly reachable. Flutterwave sends POST requests to the endpoint and expects HTTP 200 responses. The server verifies the `flutterwave-signature` HMAC-SHA256 header using the secret hash.

For a real Shopify payment workflow, do not mark an order paid merely because a webhook says "successful". Independently verify the transaction with Flutterwave and confirm the expected amount, currency, and transaction reference before giving value.

The current server intentionally does not change Shopify orders yet because that requires your Shopify Admin API credentials and a defined way to map each Flutterwave transaction to its Shopify order.
